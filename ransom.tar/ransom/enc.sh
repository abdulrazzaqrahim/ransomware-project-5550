for file_var_abs_path in $(find ~/Desktop/target-folder -type f)
do
#echo $file_var_abs_path
openssl rsautl -encrypt -inkey public_key.pem -pubin -in $file_var_abs_path -out $file_var_abs_path.enc;
echo $file_var_abs_path encrypted
rm $file_var_abs_path

done
